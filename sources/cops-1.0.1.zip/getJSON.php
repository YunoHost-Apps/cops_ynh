<?php
/**
 * COPS (Calibre OPDS PHP Server) HTML main script
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Sébastien Lucas <sebastien@slucas.fr>
 *
 */

    require_once ("config.php");
    require_once ("JSON_renderer.php");

    header ("Content-Type:application/json;charset=utf-8");


    echo json_encode (JSONRenderer::getJson ());

