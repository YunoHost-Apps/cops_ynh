function postRefresh()
{
    $('[data-toggle="tooltip"]').tooltip();
}